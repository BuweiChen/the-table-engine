https://oco.itch.io/cyberpunk-character-pack?download
https://clembod.itch.io/warrior-free-animation-set
https://rvros.itch.io/animated-pixel-hero