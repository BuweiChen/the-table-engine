var classProjectileScript =
[
    [ "ProjectileScript", "classProjectileScript.html#a8cdf784ecb3f628418413f87be9d5e9e", null ],
    [ "update", "classProjectileScript.html#a935d4734b9f8d6eaaea8c9bebd5ad4e1", null ],
    [ "m_dx", "classProjectileScript.html#a27b3581515a82e9b45049475d8da06a7", null ],
    [ "m_dy", "classProjectileScript.html#a2d32f3e33e81d8fe9c50583f8d3fdee1", null ]
];