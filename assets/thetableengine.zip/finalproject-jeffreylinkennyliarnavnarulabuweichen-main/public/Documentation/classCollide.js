var classCollide =
[
    [ "Collide", "classCollide.html#abd014fc76543f43f396c7ac9c2abb925", null ],
    [ "~Collide", "classCollide.html#a606ee95c5cbe30f489472d5ef03f51a4", null ],
    [ "getRect", "classCollide.html#ae2c44af7e1ebf9d4ac10825e781bd92b", null ],
    [ "getScreenPosition", "classCollide.html#ac4687eafc64423028dae0ced49b334c1", null ],
    [ "getScreenSize", "classCollide.html#abec7904eb11b60500bbe0b1392955b1e", null ],
    [ "isColliding", "classCollide.html#a2fb8ea39b4504c2d4b7ba771da59b80a", null ],
    [ "isColliding", "classCollide.html#ac07a519101d41dbb5a85796a4fdabbef", null ],
    [ "nextRect", "classCollide.html#ab252c3bc13d6f53562ad252c5cb3fa2b", null ],
    [ "preventCollision", "classCollide.html#a5d76a6a88c477850fc4e60c6a0ed3c3a", null ],
    [ "render", "classCollide.html#aa5d54c6b2b772ad9554cf1e7d71c0070", null ],
    [ "setScreenPosition", "classCollide.html#ab88bf8decd181648d4b2a455c74c6013", null ],
    [ "setScreenPosition", "classCollide.html#ad60453f6d3bbab00eecc4e91275a2c3f", null ],
    [ "setScreenSize", "classCollide.html#a7c6aeb5d10231afd9d5fa99f61281a8a", null ],
    [ "setScreenSize", "classCollide.html#a534eba6d660ecee83bed720f4b8bc32e", null ],
    [ "setTransformOffset", "classCollide.html#aac38103e49dc33437b459d838347386c", null ],
    [ "update", "classCollide.html#ac62d7dd9606aa4edab0b50d0d4f39271", null ],
    [ "mCollide", "classCollide.html#a1330d49e5dff6eca1b2d1a4783f8f970", null ],
    [ "mOffsetX", "classCollide.html#a3feec06f24cde65a78ed4479a36e92f6", null ],
    [ "mOffsetY", "classCollide.html#a7d3787a7e3df64d4a0a9aa911678c074", null ]
];